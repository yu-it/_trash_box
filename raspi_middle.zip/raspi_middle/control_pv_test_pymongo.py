import time
import pymongo



def SubscribeControlMessage(db, pvid, previous_processed_req_id, timeout_second):
    if (timeout_second == 0) :
        time_remain = 120
    else:
        time_remain = min(timeout_second, 120)
    countdown = 1
    target_queue = pvid + "_queue"
    print(target_queue)
    if (previous_processed_req_id == ""):
        previous_processed_req_id = db[target_queue].findOne({"init" : True})["_id"]
    print("gt " + previous_processed_req_id)
    await_cursor = db[target_queue].find({_id:{ "$gt": previous_processed_req_id }},cursor_type=pymongo.CursorType.TAILABLE_AWAIT)
    await_cursor.addOption(DBQuery.Option.tailable)
    await_cursor.addOption(DBQuery.Option.awaitData)
    while time_remain:
        print("time_remaining " + time_remain)
        if ( await_cursor.hasNext()):
            print("accepted")
            got = await_cursor.next()
            return {"req_id":got._id, "message":got["message"], "arg": got["arg"]}
        time_remain -= countdown
    
    return None





def show_receive_data(data):
    print (data)

client = pymongo.MongoClient('localhost', 27017)


db = client.test

id = db.system_js.RegistControllerProvider({"pvname":"wait_and_out","queue_size":5000, "available_message":[{"message_name":"mess_a","arg_count":3},{"message_name":"mess_b","arg_count":1}]})
last_req_id = ""

while True:
    print("start")
    mess = SubscribeControlMessage(db,id, last_req_id, 1)
    print("ret")
    if mess <> None:
        print (mess)
        show_receive_data(mess[u'req_id'])
        db.system_js.Acknowledge(id, mess[u'req_id'])
        last_req_id = mess[u'req_id']
    show_receive_data("loop:" + id)
    


