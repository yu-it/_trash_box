db.loadServerScripts()

var id = RegistControllerProvider({"pvname":"wait_and_out","queue_size":5000, "available_message":[{"message_name":"mess_a","arg_count":3},{"message_name":"mess_b","arg_count":1}]})
var last_req_id = ""
while (true) {
    mess = SubscribeControlMessage(id, last_req_id, 1)
    if (mess != null) {
        print(mess['req_id'])
        print(mess['message'])
        print(mess['arg'])
        Acknowledge(id, mess['req_id'])
        last_req_id = mess['req_id']
    }
    print("loop:" + id)
    

}
