//pythonです

import time
import pymongo

def show_receive_data(data):
    print (data)

client = pymongo.MongoClient('localhost', 27017)


db = client.test

id = db.system_js.RegistControllerProvider({"pvname":"wait_and_out","queue_size":5000, "available_message":[{"message_name":"mess_a","arg_count":3},{"message_name":"mess_b","arg_count":1}]})
last_req_id = ""
while True:
    mess = db.system_js.SubscribeControlMessage(id, last_req_id, 1)
    if mess <> None:
        print (mess)
        show_receive_data(mess[u'req_id'])
        db.system_js.Acknowledge(id, mess[u'req_id'])
        last_req_id = mess[u'req_id']
    show_receive_data("loop")
    

