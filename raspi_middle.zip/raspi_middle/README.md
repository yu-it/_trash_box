"# raspi_middle" 

mongoの設定


git clone https://github.com/nmcl/mongo4pi
cd mongo4pi
tar zxf mongo.tar.gz
cd mongo
sudo cp -r bin/* /usr/bin/
sudo cp -r include/*  /usr/include/
sudo cp -r lib/* /usr/lib/
sudo adduser --firstuid 100 --ingroup nogroup --shell /etc/false --disabled-password --gecos "" --no-create-home mongodb
sudo mkdir /var/log/mongodb/
sudo mkdir /var/lib/mongodb/
sudo chown mongodb:nogroup /var/log/mongodb/
sudo chown mongodb:nogroup /var/lib/mongodb/ 
cd ../
git clone https://github.com/RickP/mongopi
cd mongopi/debian
sudo cp init.d /etc/init.d/mongod
sudo cp mongodb.conf /etc/
sudo chmod u+x /etc/init.d/mongod
sudo update-rc.d mongod defaults

(ここまで)mongoの設定