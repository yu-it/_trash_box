db.loadServerScripts()
var target_id = ""
AvailableControllerProvider().forEach(function(rec) {
    target_id = rec["pvid"]
})
//target_id = "58a988bf92f42da26fe1d1c8"
SendToController(target_id,"mess_a",[1,2,3], 0)

