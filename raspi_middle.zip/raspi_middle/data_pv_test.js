db.loadServerScripts()

var tmp = RegistDataProvider({})
var res_test_pvname_c_require = ("error" in tmp)
print("--------------")
print(tmp)
var tmp = RegistDataProvider({pvname:"name"})
var res_test_type_c_require = ("error" in tmp)
print("--------------")
print(tmp)
var tmp = RegistDataProvider({pvname:"name",type:"num"})
var res_test_queue_c_require = ("error" in tmp)
print("--------------")
print(tmp)
var tmp = RegistDataProvider({pvname:"name",type:"aaa", queue_size:1000})
var res_test_type_c_invalid = ("error" in tmp)
print("--------------")
print(tmp)

var tmp = RegistDataProvider({pvname:"name",type:"num", queue_size:1000})
var res_ok_num = (typeof tmp) == "string" 
print("--------------")
print(tmp)

var tmp = RegistDataProvider({pvname:"name",type:"video", queue_size:1000})
var res_ok_video = (typeof tmp) == "string"
print("--------------")
print(tmp)


var tmp = RegistDataProvider({pvname:"name",type:"message", queue_size:1000})
var res_ok_message = (typeof tmp) == "string"
print("--------------")
print(tmp)

print(res_test_pvname_c_require)
print(res_test_type_c_require)
print(res_test_queue_c_require)
print(res_test_type_c_invalid	)
print(res_ok_num)
print(res_ok_video)
print(res_ok_message)
