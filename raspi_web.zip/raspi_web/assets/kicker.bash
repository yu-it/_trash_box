
mongo /home/pi/bin/programs/github/raspi_middle/stored_proc.js
cd /home/pi/bin/programs/github/raspi_web/assets/
node ./bin/www >> ./apl.log
