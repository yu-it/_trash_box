
function log(str){
	var d = new Date();
var year  = d.getFullYear();
var month = d.getMonth() + 1;
var day   = d.getDate();
var hour  = ( d.getHours()   < 10 ) ? '0' + d.getHours()   : d.getHours();
var min   = ( d.getMinutes() < 10 ) ? '0' + d.getMinutes() : d.getMinutes();
var sec   = ( d.getSeconds() < 10 ) ? '0' + d.getSeconds() : d.getSeconds();
console.log( year + '-' + month + '-' + day + ' ' + hour + ':' + min + ':' + sec + "  " + str );
}

 var pug =require("pug")

module.exports.SendControllMessage = function (pvid, message, args, timeout_second,res){
  var MongoClient = require('mongodb').MongoClient
    , assert = require('assert');
  
  // Connection URL
  var url = 'mongodb://localhost:27017/test';
  log("★★★send control start★★★")
  // Use connect method to connect to the server
  MongoClient.connect(url, function(err, db) {
    log("★★★connected★★★")
    ObId = require('mongodb').ObjectId
    var req_id = new ObId().toString()
    var target_queue = pvid + "_queue"
    var target_queue_accepted = pvid + "_accepted"
    
    //var time_remain = timeout_second;
    //var countdown = timeout_second ? 1 : 0;
    var time_remain = 0
    if (timeout_second == 0) {
        time_remain = 120
    } else {
        time_remain = Math.min(timeout_second, 120);

    }
    var countdown = 1;
    db.collection("controller_provider").findOne({"_id":pvid}, {},function(err, dat) {
        db.collection(target_queue).insertOne({"_id": req_id, "message":message, "arg":args, "init": false})
        log("★★★message inserted★★★")
        if (dat == null) {
                res.writeHead(500, { 'Content-Type': 'application/json' });

                res.end(JSON.stringify({"ret":-1, "pvid":pvid}));

        }
        var await_cursor_src = db.collection(target_queue_accepted).find({"_id":req_id}, {tailable:true,await_data:true});
        var await_cursor = await_cursor_src.stream();
        await_cursor_src.processed = 0
        await_cursor.on('data', function(document) {
                log("★★★accepted★★★")
                res.writeHead(200, { 'Content-Type': 'application/json' });

                if (document.tag.ret =="1") {
                       log("★★★create html★★★"+document.tag.u)
                       var ctrls = db.collection("controller_provider").find({"_id":{"$in":document.tag.u}}).stream()
                       ctrls.cpvid = []
                       ctrls.ccontents = []
                       
                       ctrls.on("data",function(d){
                               log("★★★got data★★★" + JSON.stringify(d))
                               var amess=[]
                               var acount=[]
                               d.available_message.forEach(function(mess_rec){
                                       amess.push(mess_rec.message_name)
                                       acount.push(mess_rec.arg_count)
                                       })
                               log("★★★end dataprovider mo yare★★★" + pug.renderFile("./views/controller.pug",{ pvid: d["_id"],pvname: d.pvname,available_message: amess,arg_count: acount}))
                               ctrls.cpvid.push(d["_id"])
                               ctrls.ccontents.push(pug.renderFile("./views/controller.pug",{ pvid: d["_id"],pvname: d.pvname,available_message: amess,arg_count: acount}))
                        
                               log("★★★shuutyou★★★")
                               
                       })
                       ctrls.on("end",function(){
                       	log("★★★end end")

                       	
                       	
//---------------------
                       	
var datas = db.collection("data_provider").find({"_id":{"$in":document.tag.u}}).stream()
                       datas.cpvid = []
                       datas.ccontents = []
                       
                       datas.on("data",function(d){
                               log("★★★got data★★★" + JSON.stringify(d))
                               
                               log("★★★end dataprovider mo yare★★★" + pug.renderFile("./views/data_view.pug",{ pvid:d["_id"],pvname: d.pvname,type: d.type}))
                               datas.cpvid.push(d["_id"])
                               datas.ccontents.push(pug.renderFile("./views/data_view.pug",{ pvid:d["_id"],pvname: d.pvname,type: d.type}))
                        
                               log("★★★shuutyou★★★")
                               
                       })
                       datas.on("end",function(){
                       	log("★★★end end")
                       	
                       	
                       	log(JSON.stringify({"restype":"modify","ctags":[ctrls.cpvid,ctrls.ccontents],"dtags":[datas.cpvid,datas.ccontents],"del":document.tag.d}))
                       	res.end(JSON.stringify({"restype":"modify","ctags":[ctrls.cpvid,ctrls.ccontents],"dtags":[datas.cpvid,datas.ccontents],"del":document.tag.d}))
                       	await_cursor_src.processed += 1
                        await_cursor_src.close()
                       })
                               
                               
                       	
                       	
// ---------------------------
                       	
                       	
                       	
                       	
                       	
                       	
                       	
                       	
                       })
                               
                               
                               
                               
                       
                               
                } else {
                       res.end(JSON.stringify({"ret":0, "tag":document.tag}));
                }
      
                

                //acceptedはDeleteProviderで消すとacceptedがないことによるこの処理への待ちがたまにでるからDeleteでは消してない。
        });
        await_cursor.on('end', function() {

            log("★★★end once:" + await_cursor_src.processed )
        });

            
    });
  })
}


module.exports.SubscribeControlMessage = function(pvid,previous_processed_req_id, timeout_second, res) {
  var MongoClient = require('mongodb').MongoClient
    , assert = require('assert');
  
  // Connection URL
  var url = 'mongodb://localhost:27017/test';
  
  // Use connect method to connect to the server
  MongoClient.connect(url, function(err, db) {
    if (timeout_second == 0) {
        time_remain = 120
    } else {
        time_remain = Math.min(timeout_second, 120);

    }
    var countdown = 1;
    var target_queue = pvid + "_queue"

    var subscribing_proc = function(previous_processed_req_id) {
        log("###gt " + previous_processed_req_id)
        var await_cursor_src = db.collection(target_queue).find({_id:{ $gt: previous_processed_req_id }}, {tailable:true})
        var await_cursor = await_cursor_src.stream();
        await_cursor.on('data', function(got) {
            log("###accepted")
            log("###" + JSON.stringify({"req_id":got._id, "message":got["message"], "arg": got["arg"]}))
            res.writeHead(200, { 'Content-Type': 'application/json' });

            res.end(JSON.stringify({"req_id":got._id, "message":got["message"], "arg": got["arg"]}));
            await_cursor_src.close()
        });
        await_cursor.on('end', function() {

        });
    }

    if (previous_processed_req_id == "") {
        db.collection(target_queue).findOne({"init" : true},function(err, docs) {
            subscribing_proc(docs["_id"])

        });
        
    } else {
        subscribing_proc(previous_processed_req_id)

    }
  })
}
