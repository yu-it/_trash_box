routine_process()
function routine_process() {
    setTimeout(function() {
        update_logging_data()
        routine_process()
    }, 1000);
}
function update_logging_data() {
    var data_views = $(".field_data").children("div");
    for(var i=0; i < data_views.length; i++) {
        var view = data_views.eq(i);
        var splited_id = view.attr("id").split("_")
        if (splited_id[0] == "video") {
            continue
        }
        var pvid = splited_id[1]
        var urlstr = "fw/GetOvservationData?pvid=" + pvid + "&previous_processed_data_id=" + view.attr("previous_processed_data_id")
        $.ajax(
        {
        url:urlstr,
        success :
            function(msg) {
            var htm = ""
            if (Array.isArray(msg)) {
                msg.forEach(function(entry){
                    $("#num_" + entry.pvid).html(entry.data)
                    view.attr("previous_processed_data_id",entry.data_id)
                })
            }
            },
        error : control_error_handler
        }
        )
    }
        
}

    

function control_error_handler(msg) {
    if (msg.responseJSON.ret == "-1") {
        alert( "controller nashi")
        //$("#area_" + msg.responseJSON.pvid).remove()
        create_ui()
    } else {
        alert( "controller oyj")

    }

}