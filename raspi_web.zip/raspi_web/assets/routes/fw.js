var express = require('express');
var pvcs = require('../logics/pv_consumer');
var router = express.Router();


function call_stored_procedure(func) {
  var MongoClient = require('mongodb').MongoClient
    , assert = require('assert');
  
  // Connection URL
  var url = 'mongodb://localhost:27017/test';
  
  // Use connect method to connect to the server
  MongoClient.connect(url, function(err, db) {
    assert.equal(null, err);
  
    db.eval('db.loadServerScripts()',
      //err
      function(err,seq) {
        func(err,seq,db);
      }
    )
 
  });

}

/* GET users listing. */
router.get('/AvailableControllerProvider', function(req, res, next) {
      call_stored_procedure(function(err,seq, db) {
        db.eval('AvailableControllerProvider()',
          function(err,seq) {
            console.log(seq)
            res.send(seq);
         }
        )
      });

});
router.get('/SendToController', function(req, res, next) {
      /*
      var call_script = 'SendToController("' + req.query.pvid + '","'
                + req.query.message + '",'
                + '["' + req.query.arg + '"], 1)'
      console.log("start")
      call_stored_procedure(function(err,seq, db) {
        db.eval(call_script,
          function(err,seq) {
            console.log(seq)
            res.send(200);
         }
        )
      });
      */
       pvcs.SendControllMessage(req.query.pvid ,req.query.message, req.query.arg, 100,res)
});
router.get('/SubscribeControlMessage', function(req, res, next) {
      /*
      var call_script = 'SendToController("' + req.query.pvid + '","'
                + req.query.message + '",'
                + '["' + req.query.arg + '"], 1)'
      console.log("start")
      call_stored_procedure(function(err,seq, db) {
        db.eval(call_script,
          function(err,seq) {
            console.log(seq)
            res.send(200);
         }
        )
      });
      */
      pvcs.SubscribeControlMessage(req.query.pvid ,req.query.previous_processed_req_id, 100,res)
});
/* GET users listing. */
router.get('/AvailableDataProvider', function(req, res, next) {
      call_stored_procedure(function(err,seq, db) {
        db.eval('AvailableDataProvider()',
          function(err,seq) {
            console.log(seq)
            res.send(seq);
         }
        )
      });

});
router.get('/GetOvservationData', function(req, res, next) {
      call_stored_procedure(function(err,seq, db) {
        var expr = 'GetOvservationData("' + req.query.pvid + '","' + req.query.previous_processed_data_id + '")'
        db.eval(expr,
          function(err,seq) {
            console.log(seq)
            res.send(seq);
         }
        )
      });

});

module.exports = router;
