var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/controller', function(req, res, next) {
  console.log(req.query)
  res.render('controller', { pvid: req.query.pvid,pvname: req.query.pvname,available_message: req.query.available_message,arg_count: req.query.arg_count});
});

router.get('/data_view', function(req, res, next) {
  console.log(req.query)
  res.render('data_view', { pvid: req.query.pvid,pvname: req.query.pvname,type: req.query.type});
});

module.exports = router;
