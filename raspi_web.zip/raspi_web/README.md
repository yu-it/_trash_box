"# raspi_web" 
#インストールしたnpmパッケージ 
これはNode.jsで動いています。インストールしたnpmパッケージは下記の通り。 
1. express-genのデフォルトパッケージ
2. npm install mongodb
